const fs = require('fs');
const path = require('path');
const config = require('../config');
const { logger } = require('./logger');
const moment = require('moment-timezone'); // Wajib buat CCTV Grafik Jam

const commands = new Map();
global.afkStorage = global.afkStorage || new Map();
global.db = global.db || {};
global.db.chats = global.db.chats || {};
global.db.groups = global.db.groups || {}; // DATABASE BARU BUAT TOP AKTIF & STATS

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    if (hours > 0) return `${hours} jam ${minutes % 60} menit`;
    if (minutes > 0) return `${minutes} menit ${seconds % 60} detik`;
    return `${seconds} detik`;
}

function loadCommands() {
    commands.clear(); 
    const commandsPath = path.join(__dirname, '../commands');
    function readDirRecursively(dir) {
        const items = fs.readdirSync(dir);
        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                readDirRecursively(fullPath);
            } else if (stat.isFile() && item.endsWith('.js')) {
                try {
                    delete require.cache[require.resolve(fullPath)];
                    const command = require(fullPath);
                    if (command && command.name) {
                        commands.set(command.name, command);
                    }
                } catch (err) {
                    logger.error(`Error load ${item}: ${err.message}`);
                }
            }
        }
    }
    readDirRecursively(commandsPath);
    return commands;
}

async function handleMessage(sock, m, commands) {
    try {
        if (!m || !m.message) return;

        const from = m.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        const pushName = m.pushName || "User";
        const type = Object.keys(m.message)[0];
        
        // ==========================================
        // SISTEM FIX JID & LID (ANTI PROMISE ERROR)
        // ==========================================
        let mainJid = isGroup ? (m.key.participant || m.participant) : m.key.remoteJid;
        if (m.key.fromMe) mainJid = sock.user.id;

        if (sock.decodeJid) mainJid = sock.decodeJid(mainJid);

        if (mainJid && typeof mainJid === 'string' && mainJid.includes('@lid')) {
            try {
                const pn = await sock.signalRepository?.lidMapping?.getPNForLID(mainJid);
                if (pn && typeof pn === 'string') {
                    mainJid = pn; 
                } else {
                    mainJid = mainJid.replace('@lid', '@s.whatsapp.net'); 
                }
            } catch (e) {
                mainJid = mainJid.replace('@lid', '@s.whatsapp.net');
            }
        }

        const senderNumber = (typeof mainJid === 'string') ? mainJid.split('@')[0].split(':')[0] : '';
        const sender = senderNumber + '@s.whatsapp.net';
        // ==========================================

        // ==========================================
        // CCTV: REKAM JUMLAH PESAN MEMBER & GRAFIK JAM
        // ==========================================
        if (isGroup && !m.key.fromMe) {
            if (!global.db.groups[from]) global.db.groups[from] = { users: {}, hourly: {} };
            if (!global.db.groups[from].users[sender]) global.db.groups[from].users[sender] = { chat: 0 };
            if (!global.db.groups[from].hourly) global.db.groups[from].hourly = {}; 
            
            // 1. Nambah point per user
            global.db.groups[from].users[sender].chat += 1;

            // 2. Nambah point per jam (0 - 23) buat grafik bar
            const jamSekarang = moment().tz(config.timezone || 'Asia/Jakarta').format('H');
            if (!global.db.groups[from].hourly[jamSekarang]) global.db.groups[from].hourly[jamSekarang] = 0;
            global.db.groups[from].hourly[jamSekarang] += 1;
        }
        // ==========================================

        let rawBody = (
            type === 'conversation' ? m.message.conversation :
            type === 'extendedTextMessage' ? m.message.extendedTextMessage.text :
            type === 'imageMessage' ? m.message.imageMessage.caption :
            type === 'videoMessage' ? m.message.videoMessage.caption :
            type === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
            type === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            type === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId :
            (type === 'audioMessage' ? 'media_audio' : '')
        );
        
        const body = (typeof rawBody === 'string') ? rawBody.trim() : '';
        const lowerBody = body.toLowerCase();
        const prefix = config.prefix;

        const contextInfo = m.message[type]?.contextInfo;
        const quoted = contextInfo?.quotedMessage || null;
        
        // Fix LID buat Quote (pesan yang direply)
        let quotedSender = null;
        if (contextInfo?.participant) {
            let qJid = contextInfo.participant;
            if (sock.decodeJid) qJid = sock.decodeJid(qJid);
            if (qJid && typeof qJid === 'string' && qJid.includes('@lid')) {
                try {
                    const qPn = await sock.signalRepository?.lidMapping?.getPNForLID(qJid);
                    if (qPn && typeof qPn === 'string') qJid = qPn;
                } catch (e) {}
            }
            quotedSender = (typeof qJid === 'string') ? qJid.split('@')[0].split(':')[0] + '@s.whatsapp.net' : null;
        }
        
        const owners = Array.isArray(config.ownerNumber) ? config.ownerNumber : [config.ownerNumber];
        const isOwner = owners.some(num => senderNumber === num.replace(/[^0-9]/g, '')) || m.key.fromMe;

        if (!body.startsWith(prefix)) {
            if (lowerBody === "whitelist") return sock.sendMessage(from, { text: "> Link: https://discord.gg/7PhnNwdnaX" }, { quoted: m });
            if (lowerBody === "key") return sock.sendMessage(from, { text: "> Key: *SawitLiar*" }, { quoted: m });
            return;
        }

        const args = body.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = commands.get(commandName) || Array.from(commands.values()).find(cmd => cmd.alias && cmd.alias.includes(commandName));

        if (!command) return;
        if (!config.public && !isOwner) return;

        let isAdmin = false;
        if (isGroup) {
            try {
                const groupMetadata = await sock.groupMetadata(from);
                const participant = groupMetadata.participants.find(p => p.id.startsWith(senderNumber));
                isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            } catch (err) {}
        }
        
        const text = args.join(' ');
        const msg = {
            chat: from, from, sender, senderNumber, pushName, body, args, text, isOwner, isGroup, isAdmin, type,
            quoted: quoted ? { ...quoted, sender: quotedSender } : null,
            original: m,
            reply: async (content) => {
                if (typeof content === 'string') return sock.sendMessage(from, { text: content }, { quoted: m });
                return sock.sendMessage(from, content, { quoted: m });
            },
            react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: m.key } }),
            
            download: async () => {
                const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');
                let msgObj = m.message[type]?.contextInfo?.quotedMessage || m.message;
                let msgType = Object.keys(msgObj)[0];
                if (msgType === 'messageContextInfo') msgType = Object.keys(msgObj)[1]; 

                const stream = await downloadContentFromMessage(msgObj[msgType], msgType.replace('Message', ''));
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                return buffer;
            }
        };

        await command.execute(sock, msg, args, { text, prefix, command: commandName, isOwner, isAdmin, isGroup });

    } catch (error) {
        console.error("HANDLER ERROR:", error);
    }
}

module.exports = { loadCommands, handleMessage };