const moment = require('moment-timezone');

module.exports = {
    getTime: () => moment().tz('Asia/Jakarta').format('HH:mm:ss'),
    getDate: () => moment().tz('Asia/Jakarta').format('DD/MM/YYYY'),
    formatNumber: (num) => num.replace(/[^0-9]/g, '') + '@s.whatsapp.net',
    sleep: (ms) => new Promise(resolve => setTimeout(resolve, ms))
};