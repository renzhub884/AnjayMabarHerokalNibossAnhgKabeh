# SCRIPTBLOX SEARCH BOT

Bot WhatsApp untuk mencari script dari ScriptBlox.com

## Creator
**sibah**

## Fitur
- ✅ Login dengan PAIRING CODE (bukan QR)
- ✅ Search script dari ScriptBlox API
- ✅ Menu ASCII dengan dashboard
- ✅ Auto reconnect

## Commands
- `.searchscript <query>` - Cari script
- `.menu` - Tampilkan menu
- `.ping` - Cek speed bot
- `.owner` - Info owner
- `banyak lah pokonya`

## Instalasi di Pterodactyl

### 1. Upload semua file ke panel

### 2. Install dependencies
```bash
npm install