#!/bin/bash

echo "════════════════════════════════════════"
echo "   SCRIPTBLOX SEARCH BOT INSTALLER"
echo "   by sibah"
echo "════════════════════════════════════════"
echo ""

# Hapus node_modules dan package-lock.json lama
echo "🗑️  Menghapus instalasi lama..."
rm -rf node_modules
rm -f package-lock.json

# Clear npm cache
echo "🧹 Membersihkan npm cache..."
npm cache clean --force

# Install dependencies
echo "📦 Menginstall dependencies..."
npm install

# Check jika berhasil
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Instalasi berhasil!"
    echo ""
    echo "════════════════════════════════════════"
    echo "Jalankan bot dengan: node index.js"
    echo "════════════════════════════════════════"
else
    echo ""
    echo "❌ Instalasi gagal! Cek error di atas."
fi