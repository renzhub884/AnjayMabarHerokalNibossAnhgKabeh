module.exports = {
    name: 'topaktif',
    alias: ['memberaktif', 'topchat'],
    description: 'Melihat 10 member paling aktif di grup',
    async execute(sock, m, args, { isGroup }) {
        if (!isGroup) return m.reply('❌ Command ini khusus dipakai di dalam grup, wir!');

        await m.react('📊');

        try {
            // Tarik data CCTV dari global database lu
            const groupDb = global.db.groups?.[m.chat]?.users || {};
            const users = Object.keys(groupDb);

            // Kalau grupnya masih sepi / bot baru nyala
            if (users.length === 0) {
                return m.reply('⚠️ Belum ada data chat yang terekam semenjak sistem berjalan.');
            }

            // Algoritma ngurutin dari chat paling banyak ke dikit
            const sortedUsers = users.sort((a, b) => groupDb[b].chat - groupDb[a].chat);
            
            // Ambil Top 10
            const top10 = sortedUsers.slice(0, 10);

            let teks = `╭━━━〔 *TOP AKTIF MEMBER* 〕━━━┈ ⳹\n`;
            
            // Medali kita perpanjang sampai 10
            const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

            for (let i = 0; i < top10.length; i++) {
                const jid = top10[i];
                const count = groupDb[jid].chat;
                const num = jid.split('@')[0];
                
                // Sengaja pake format angka murni tanpa '@' biar kaga jadi biru (Hidetag)
                teks += `┃ ${medals[i]} ${num} ➪ ${count} Pesan\n`;
            }

            teks += `╰━━━━━━━━━━━━━━━━━━━━━━┈ ⳹\n\n`;
            teks += `_© Sawit Community_`;

            // ==========================================
            // KUNCI HIDETAG SILENT KILLER
            // ==========================================
            await sock.sendMessage(m.chat, {
                text: teks,
                mentions: top10 
            }, { quoted: m.original });

            await m.react('✅');

        } catch (err) {
            console.error('[TOPAKTIF ERROR]', err);
            await m.react('❌');
            m.reply('❌ Terjadi kesalahan saat menarik data member aktif.');
        }
    }
};
