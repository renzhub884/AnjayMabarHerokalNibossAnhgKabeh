const axios = require('axios');

module.exports = {
    name: 'stats',
    alias: ['statistik', 'infogrup', 'gcstats'],
    description: 'Melihat statistik grafik dan total chat grup',
    async execute(sock, m, args, { isGroup }) {
        if (!isGroup) return m.reply('❌ Command elit ini cuma bisa dipakai di grup!');

        await m.react('📊');

        try {
            // 1. AMBIL METADATA GRUP
            const groupMetadata = await sock.groupMetadata(m.chat);
            const groupName = groupMetadata.subject;
            const participants = groupMetadata.participants;
            const memberCount = participants.length;

            // Filter siapa aja adminnya
            const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
            const adminCount = admins.length;

            // 2. AMBIL DATA DARI DATABASE CCTV KITA
            const groupDb = global.db.groups?.[m.chat] || { users: {}, hourly: {} };
            
            // Ngitung total SEMUA pesan di grup ini
            let totalMessages = 0;
            for (const jid in groupDb.users) {
                totalMessages += groupDb.users[jid].chat;
            }

            // 3. SUSUN DATA GRAFIK (24 JAM)
            const hourlyData = [];
            for (let i = 0; i < 24; i++) {
                hourlyData.push(groupDb.hourly[i] || 0);
            }

            // 4. BIKIN URL GENERATOR GRAFIK (QuickChart API)
            // Tema disamain persis kayak referensi foto lu (Dark Theme, Bar Ungu)
            const chartConfig = {
                type: 'bar',
                data: {
                    labels: ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'],
                    datasets: [{
                        label: 'Jumlah Pesan',
                        data: hourlyData,
                        backgroundColor: 'rgba(128, 90, 213, 0.9)', // Warna Bar Ungu
                        borderColor: 'rgba(128, 90, 213, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    legend: { display: false },
                    title: { display: true, text: 'Grafik Aktivitas Chat (24 Jam)', fontColor: '#ffffff' },
                    scales: {
                        yAxes: [{ ticks: { fontColor: '#ffffff', beginAtZero: true }, gridLines: { color: 'rgba(255,255,255,0.1)' } }],
                        xAxes: [{ ticks: { fontColor: '#ffffff' }, gridLines: { display: false } }]
                    }
                }
            };
            
            const chartUrl = `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify(chartConfig))}&bkg=rgb(34,34,34)&w=800&h=400`;

            // 5. SUSUN CAPTION ESTETIK
            let teks = `╭━━━〔 *STATISTIK GRUP* 〕━━━┈ ⳹\n`;
            teks += `┃ 🏷️ *Nama:* ${groupName}\n`;
            teks += `┃ 👥 *Members:* ${memberCount}\n`;
            teks += `┃ 👑 *Admins:* ${adminCount}\n`;
            teks += `┃ 💬 *Total Chat:* ${totalMessages}\n`;
            teks += `╰━━━━━━━━━━━━━━━━━━━━━━┈ ⳹\n\n`;

            teks += `*Group Managed By:*\n`;
            // Nampilin max 10 admin biar kaga kepanjangan banget
            const displayAdmins = admins.slice(0, 10);
            for (const adm of displayAdmins) {
                const num = adm.id.split('@')[0];
                teks += `› wa.me/${num}\n`;
            }
            if (adminCount > 10) teks += `_...dan ${adminCount - 10} admin lainnya._\n`;

            teks += `\n_made by Xploria Ai_`;

            // 6. KIRIM HASIL (GAMBAR GRAFIK + TEKS)
            await sock.sendMessage(m.chat, { 
                image: { url: chartUrl },
                caption: teks 
            }, { quoted: m.original });

            await m.react('✅');

        } catch (err) {
            console.error('[STATS ERROR]', err);
            await m.react('❌');
            m.reply('❌ Gagal merender grafik statistik grup!');
        }
    }
};
