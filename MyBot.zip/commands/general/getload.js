const config = require('../../config');

module.exports = {
    name: 'getload',
    alias: ['gl', 'getsc'],
    description: 'Mengambil loadstring murni dari hasil pencarian SSC',
    async execute(sock, msg, args) {
        // Cek apakah ada quoted dan teks di dalamnya
        if (!msg.quoted || !msg.quoted.text) {
            return msg.reply("❌ *Reply dulu woi pesan nya 😡*\n\nSilakan balas (reply) pesan hasil .ssc lalu ketik *.getload 1*");
        }

        const selection = parseInt(args[0]);
        if (isNaN(selection)) {
            return msg.reply("❌ Masukkan nomor! Contoh: *.getload 1*");
        }

        try {
            // Regex lebih kuat untuk menangkap loadstring
            const regex = /loadstring\(game:HttpGet\(["'][\s\S]*?["']\)\)\(\)/g;
            const matches = msg.quoted.text.match(regex);

            if (matches && matches.length >= selection) {
                let finalLoadstring = matches[selection - 1];
                
                // Bersihkan karakter aneh
                finalLoadstring = finalLoadstring.replace(/`/g, '').trim();
                
                await sock.sendMessage(msg.from, { text: finalLoadstring }, { quoted: msg.original });
                await msg.react('✅');
            } else {
                msg.reply(`❌ Loadstring nomor ${selection} tidak ditemukan. Pastikan kamu reply pesan yang ada loadstring-nya!`);
            }

        } catch (error) {
            console.error('GetLoad Error:', error);
            msg.reply("❌ Terjadi kesalahan saat memproses script.");
        }
    }
};
