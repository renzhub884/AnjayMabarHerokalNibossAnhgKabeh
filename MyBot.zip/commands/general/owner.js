const config = require('../../config');

module.exports = {
    name: 'owner',
    alias: ['pencipta', 'developer'],
    description: 'Info owner bot',
    async execute(sock, msg, args) {
        const { from } = msg;

        // Ambil data dari config, kalau kosong kasih default biar ga eror
        const ownerName = config.ownerName || "Alrect / Sibah";
        const botName = config.botName || "Xploria AI";

        let ownerInfo = `*─── [ OWNER PROFILE ] ───*\n\n`;
        ownerInfo += `Greetings! Berikut adalah kontak resmi owner kami untuk informasi lebih lanjut.\n\n`;
        
        ownerInfo += `┌  ─── [ *DEVELOPER* ]\n`;
        ownerInfo += `│  ◦  *Nama:* ${ownerName}\n`;
        ownerInfo += `│  ◦  *Bot:* ${botName}\n`;
        ownerInfo += `│  ◦  *Status:* Active / Online\n`;
        ownerInfo += `└  ───────────────────\n\n`;

        ownerInfo += `*Official Contacts:*\n`;
        ownerInfo += `> 1. https://wa.me/6285800159659 (Sibah)\n`;
        ownerInfo += `> 2. https://wa.me/6282192401340 (Alrect)\n\n`;

        ownerInfo += `_Silahkan hubungi jika ada keperluan penting._`;

        try {
            await sock.sendMessage(from, { 
                text: ownerInfo,
                contextInfo: {
                    externalAdReply: {
                        title: `OWNER ${botName.toUpperCase()}`,
                        body: "Tap to chat with developers",
                        thumbnailUrl: "https://files.catbox.moe/i62im4.jpg",
                        sourceUrl: "https://wa.me/6285800159659",
                        renderLargerThumbnail: true,
                        showAdAttribution: false // Matikan ini dulu wir kalau sering bikin chat ga respon/delay
                    }
                }
            }, { quoted: msg.original });

            // Opsional: Kirim VCard biar orang tinggal save
            const vcard = 'BEGIN:VCARD\n' 
                + 'VERSION:3.0\n' 
                + `FN:${ownerName}\n` 
                + 'ORG:Xploria Developer;\n' 
                + 'TEL;type=CELL;type=VOICE;waid=6285800159659:+62 858-0015-9659\n' 
                + 'END:VCARD';

            await sock.sendMessage(from, {
                contacts: {
                    displayName: ownerName,
                    contacts: [{ vcard }]
                }
            }, { quoted: msg.original });

        } catch (e) {
            console.error("Owner Command Error:", e);
            // Fallback: Kirim teks biasa kalau AdReply gagal
            await msg.reply(ownerInfo);
        }
    }
};
