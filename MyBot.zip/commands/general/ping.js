module.exports = {
    name: 'ping',
    description: 'Cek kecepatan respon bot',
    async execute(sock, msg, args) {
        const start = Date.now();
        await msg.reply('🏓 Pinging...');
        const end = Date.now();
        
        const latency = end - start;
        await msg.reply(`🏓 *PONG!*\n\n⚡ Speed: ${latency}ms`);
    }
};