module.exports = {
    name: 'afk',
    description: 'Set status AFK dengan alasan',
    async execute(sock, msg, args) {
        const reason = args.join(' ') || 'Tanpa alasan';
        
        global.afkStorage.set(msg.sender, {
            reason: reason,
            time: Date.now()
        });

        const teks = `💤 *ᴀꜰᴋ ᴀᴋᴛɪꜰ*\n\n` +
                     `@${msg.sender.split('@')[0]} sekarang AFK\n` +
                     `🍀 \`Alasan:\` *${reason}*\n\n` +
                     `_Ketik apapun untuk menonaktifkan AFK._`;

        await sock.sendMessage(msg.from, { 
            text: teks, 
            mentions: [msg.sender] 
        });
        
        await msg.react('💤');
    }
};
