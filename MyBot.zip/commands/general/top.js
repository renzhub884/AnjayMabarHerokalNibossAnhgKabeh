module.exports = {
    name: 'top',
    alias: ['top5', 'topglobal'],
    description: 'Menampilkan top 5 member secara random di grup',
    async execute(sock, m, args, { isGroup }) {
        if (!isGroup) return m.reply('❌ Command kocak ini cuma bisa dipakai di dalam grup, wir!');
        
        if (args.length === 0) return m.reply('⚠️ Masukin kategori top apa dulu!\nContoh: *.top orang paling ganteng*');

        await m.react('🔍');

        try {
            const textTop = args.join(' ').toUpperCase();
            const metadata = await sock.groupMetadata(m.chat);
            
            // Wajib filter s.whatsapp.net biar bot cuma milih nomor asli yang BISA ditag.
            // ID @lid dibuang karena WA ga support tag pakai lid.
            const participants = metadata.participants
                .map(p => p.id)
                .filter(id => id.endsWith('@s.whatsapp.net'));

            // Kalau error "Member tidak ada" muncul lagi, berarti grup itu emang isinya lid semua (misal grup Announcement Komunitas)
            if (!participants || participants.length === 0) {
                return m.reply('❌ Member nggak bisa ditag! (Grup ini nge-hide nomor member jadi lid semua)');
            }

            // Acak
            const shuffled = participants.sort(() => 0.5 - Math.random());
            const topCount = Math.min(5, shuffled.length);
            const selected = shuffled.slice(0, topCount);

            let teks = `🏆 *TOP ${topCount} ${textTop}* 🏆\n\n`;

            // Array untuk menyimpan mentions
            let mentions = [];

            for (let i = 0; i < selected.length; i++) {
                const jid = selected[i];
                
                // Ambil nomor asli
                const number = jid.split('@')[0].split(':')[0]; 

                // Format WA wajib pakai @nomor di teksnya
                teks += `*${i + 1}.* @${number}\n`;

                // Push JID utuh ke array mentions
                mentions.push(jid);
            }
            
            teks += `\n_© Sawit Community_`;

            // Kirim dengan mentions yang benar
            await sock.sendMessage(m.chat, { 
                text: teks, 
                mentions: mentions
            }, { quoted: m.original });

            await m.react('✅');

        } catch (err) {
            console.error('[TOP ERROR]', err);
            await m.react('❌');
            m.reply('❌ Error: ' + err.message);
        }
    }
};
