module.exports = {
    name: 'tebak',
    alias: ['ramal', 'cek'],
    description: 'Game tebak-tebakan dengan opsi random',
    async execute(sock, m, args) {
        if (args.length === 0) {
            return m.reply('⚠️ Kasih tau dulu apa yang mau ditebak!\nContoh: *.tebak aku ini orangnya gimana?*');
        }

        const query = args.join(' ');
        await m.react('🔮');

        // Bank pasangan kata-kata random (bisa lu tambahin sendiri nanti)
        const opsiRandom = [
            ['Ganteng Parah 😎', 'Jelek Brutal 🤮'],
            ['Wibu Akut 🤓', 'Normies 🌍'],
            ['Pro Player 🎮', 'Beban Tim 🗑️'],
            ['Wangi Mewah 🌸', 'Bau Bawang 🧅'],
            ['Suhu Sepuh 🔥', 'Ampas Kopi 💩'],
            ['Sipaling Bener 💯', 'Tukang Ngibul 🤥'],
            ['Keren Parah 🥶', 'Cringe Abis 😬'],
            ['Crazy Rich 💸', 'Tukang Ngutang 🏃‍♂️💨'],
            ['Khodam Macan Putih 🐯', 'Khodam Knalpot Mber 🛵'],
            ['Idaman Mertua 🥰', 'Beban Keluarga 🗿']
        ];

        // Sistem acak milih pasangan kata
        const randomIndex = Math.floor(Math.random() * opsiRandom.length);
        const [opsi1, opsi2] = opsiRandom[randomIndex];

        try {
            // Kita pakai fitur Polling Baileys v7 (Pengganti Button yang diblokir Meta)
            const pollMessage = {
                name: `Pertanyaan: "${query}"\n\nPilih salah satu jawaban di bawah ini 👇`,
                values: [opsi1, opsi2],
                selectableCount: 1 // Cuma boleh pilih satu
            };

            await sock.sendMessage(m.chat, { 
                poll: pollMessage 
            }, { quoted: m.original });

            await m.react('✅');

        } catch (err) {
            console.error('[TEBAK ERROR]', err);
            await m.react('❌');
            m.reply('❌ Gagal bikin polling tebak-tebakan!');
        }
    }
};
