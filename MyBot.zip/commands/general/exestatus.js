const axios = require('axios');
const cheerio = require('cheerio');

const c = {
    cyan: "\x1b[36m", green: "\x1b[32m", red: "\x1b[31m", reset: "\x1b[0m"
};

module.exports = {
    name: 'exestatus',
    alias: ['executor', 'exec'],
    description: 'Menampilkan status update executor Roblox',
    async execute(sock, msg, args) {
        const { from, original, react, reply } = msg;

        try {
            await react('⏳');
            console.log(`${c.cyan}[ INFO ]${c.reset} Scraping Executor Status...`);

            const TARGET = 'https://executors.samrat.lol/';
            const PROXY = [
                'https://api.allorigins.win/raw?url=',
                'https://corsproxy.io/?'
            ];

            let html;
            for (const p of PROXY) {
                try {
                    const r = await axios.get(p + encodeURIComponent(TARGET), { timeout: 15000 });
                    if (r.data) {
                        html = r.data;
                        break;
                    }
                } catch (err) {
                    console.log(`${c.red}[ PROXY ERROR ]${c.reset} Gagal mencoba salah satu proxy...`);
                }
            }

            if (!html) throw new Error('Semua proxy gagal mendapatkan data');

            const $ = cheerio.load(html);
            const cards = $('.executor-card');

            if (!cards.length) {
                await react('❌');
                return reply('❌ Data executor tidak ditemukan.');
            }

            let text = `╔════ ⚙️ EXECUTOR STATUS ════╗\n`;
            text += `📅 ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB\n`;
            text += `━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

            cards.each((_, el) => {
                const name = $(el).find('h3').text().trim() || 'Unknown';
                const status = $(el).find('.status').text().trim() || 'Unknown';
                const download = $(el).find('a:contains("Download")').attr('href') || $(el).find('.btn-download').attr('href') || '-';
                const website = $(el).find('a').first().attr('href') || '-';

                const online = /online|updated/i.test(status);
                const icon = online ? '🟢' : '🔴';

                text += `┏━ ${name}\n`;
                text += `┃ Status : ${icon} ${status}\n`;
                text += `┃ Get    : ${download}\n`;
                text += `┃ Web    : ${website}\n`;
                text += `┗━━━━━━━━━━━━━━━━━━\n\n`;
            });

            text += `👑 *XPLORIA MONITORING*`;

            await react('✅');
            // Kirim teks saja tanpa contextInfo/thumbnail
            await sock.sendMessage(from, { text }, { quoted: original });

        } catch (e) {
            console.error(`${c.red}[ ERROR ]${c.reset} ${e.message}`);
            await react('❌');
            reply('⚠️ Gagal mengambil data executor.');
        }
    }
};
