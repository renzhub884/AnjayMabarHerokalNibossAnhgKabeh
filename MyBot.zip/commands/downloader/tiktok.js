const axios = require('axios');

module.exports = {
    name: 'tt',
    alias: ['tiktok', 'ttdl'],
    description: 'Download video TikTok tanpa WM (HD jika available) - pakai tikwm',
    async execute(sock, msg, args) {
        const { from, reply, react, original } = msg;
        const url = args[0];

        if (!url) return reply(`Contoh: .tt https://vt.tiktok.com/xxxx/`);
        if (!url.includes('tiktok.com')) return reply('❌ Masukkan link TikTok yang bener su!');

        await react('⏳');
        
        try {
            const apiResponse = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`);
            const data = apiResponse.data;

            console.log("Full tikwm response:", JSON.stringify(data, null, 2)); // Debug di panel

            if (data.code !== 0) {
                await react('❌');
                return reply(`❌ api error: ${data.msg || 'Gagal ambil data'}. Coba link lain.`);
            }

            if (!data.data) {
                await react('❌');
                return reply('❌ Eror,coba lahi nanti ya.');
            }

            const videoData = data.data;

            let videoUrl = videoData.hdplay || videoData.play || videoData.wmplay;

            if (!videoUrl) {
                await react('❌');
                return reply('❌ anjing video nya udh dihapus/private asu.');
            }

            const videoRes = await axios.get(videoUrl, {
                responseType: 'arraybuffer',
                timeout: 40000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://www.tiktok.com/'
                }
            });

            const title = videoData.title || '-';
            const caption = `*TIKTOK DOWNLOADER*\n\n📝 *Judul:* ${title}\n\n_dah selesai nih_ | XPLORIA-AI Powered`;

            await sock.sendMessage(from, { 
                video: Buffer.from(videoRes.data), 
                caption: caption,
                mimetype: 'video/mp4'
            }, { quoted: original });

            await react('✅');

        } catch (e) {
            console.error('Error TikTok tikwm:', e.message);
            await react('❌');
            let errText = '❌ Terjadi kesalahan: ' + e.message;
            if (e.code === 'ECONNABORTED') errText += ' (timeout - video besar atau lambat)';
            return reply(errText);
        }
    }
};