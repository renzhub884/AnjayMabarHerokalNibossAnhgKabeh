const axios = require("axios");

const c = {
    cyan: "\x1b[36m", green: "\x1b[32m", yellow: "\x1b[33m",
    magenta: "\x1b[35m", red: "\x1b[31m", reset: "\x1b[0m", bold: "\x1b[1m"
};

module.exports = {
    name: "play",
    alias: ["p", "song", "ytplay"],
    description: "Download lagu YouTube via Nexray API",
    async execute(sock, msg, args) {
        const { from, original, pushName, react, reply } = msg;
        const query = args.join(" ");

        if (!query) return reply("Mau cari lagu apa wir? Contoh: *.play sanfonamix*");

        console.log(`\n${c.bold}${c.magenta}============ [ YT-PLAY ] ============ ${c.reset}`);
        console.log(`${c.cyan}[ QUERY ]${c.reset} : ${query}`);
        console.log(`${c.cyan}[ USER  ]${c.reset} : ${pushName}`);

        await react("🔍");

        try {
            // 1. Menggunakan link API Nexray yang baru
            const { data } = await axios.get(
                `https://api.nexray.web.id/downloader/ytplay?q=${encodeURIComponent(query)}`
            );

            // 2. Deteksi otomatis letak datanya (antisipasi kalau formatnya beda)
            const resultData = data?.result || data?.data || data;

            if (!resultData) {
                console.log(`${c.red}[ ERROR ]${c.reset} : Hasil tidak ditemukan atau API error!`);
                await react("❌");
                return reply("❌ Lagu tidak ditemukan atau API sedang gangguan, coba judul lain!");
            }

            // 3. Menyesuaikan nama variabel secara otomatis
            const title = resultData.title || resultData.judul || "Tanpa Judul";
            const thumbnail = resultData.thumbnail || resultData.thumb || resultData.image || "https://i.ibb.co/G5mjzJc/no-image.jpg";
            const dlink = resultData.dlink || resultData.download_url || resultData.audio || resultData.url_audio || resultData.url;
            const url = resultData.url || resultData.link || resultData.source || 'https://youtube.com';

            if (!dlink) {
                 console.log(`${c.red}[ ERROR ]${c.reset} : Link audio tidak ada di response API.`);
                 await react("❌");
                 return reply("❌ Gagal mengambil audio! Sepertinya format data API belum terbaca.");
            }

            console.log(`${c.green}[ FOUND ]${c.reset} : ${title}`);

            let caption = `*YOUTUBE PLAY*\n\n`
            caption += `📝 *Judul:* ${title}\n`
            caption += `🔗 *Link:* ${url}\n\n`
            caption += `_⏳ Sedang mengirim audio..._`

            // 4. Kirim Thumbnail + Detail dulu sebagai info
            await sock.sendMessage(from, { 
                image: { url: thumbnail }, 
                caption: caption 
            }, { quoted: original });

            // 5. Kirim Audio Murni (Tanpa externalAdReply biar ga bug)
            await sock.sendMessage(from, {
                audio: { url: dlink },
                mimetype: "audio/mp4", 
                ptt: false, // Set false biar jadi audio biasa, bukan voice note
                fileName: `${title}.mp3`,
                contextInfo: {
                    forwardingScore: 0,
                    isForwarded: false
                }
            }, { quoted: original });

            await react("✅");
            console.log(`${c.bold}${c.green}[ DONE ] : BERHASIL DIKIRIM! ${c.reset}`);

        } catch (e) {
            console.log(`${c.red}[ CRASH ] : ${e.message}${c.reset}`);
            await react("❌");
            reply(`❌ Terjadi kesalahan: ${e.message}`);
        }
    }
};
