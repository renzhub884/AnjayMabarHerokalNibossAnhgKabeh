const axios = require('axios');
const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const ffmpeg = require('ffmpeg-static');

module.exports = {
    name: 'brat',
    alias: ['brattext'],
    description: 'Membuat sticker brat (Format Bot Sibah)',
    async execute(sock, msg, args) {
        const { from, original, react, reply, pushName } = msg; // Ambil variabel sesuai format botmu
        const text = args.join(' ');

        if (!text) return reply(`Contoh: .brat Hai semua`);

        await react('⏳');

        try {
            const url = `https://api.yupra.my.id/api/image/brat?text=${encodeURIComponent(text)}`;
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            const bufferData = Buffer.from(response.data);

            process.env.FFMPEG_PATH = ffmpeg; 

            const sticker = new Sticker(bufferData, {
                pack: 'rosblok ai',
                author: pushName || 'User',
                type: StickerTypes.FULL,
                quality: 100
            });

            const stickerBuffer = await sticker.toBuffer();

            await sock.sendMessage(from, { 
                sticker: stickerBuffer 
            }, { quoted: original });

            await react('✅');

        } catch (error) {
            console.error('Brat Error:', error.message);
            await react('❌');
            reply(`❌ Error: ${error.message}`);
        }
    }
};
