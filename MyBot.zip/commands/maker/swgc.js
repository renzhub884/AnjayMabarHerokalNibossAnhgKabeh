module.exports = {
    name: 'swgc',
    alias: ['statusgc', 'storygc', 'upgc', 'swgv', 'upswgc'],
    description: 'Upload pesan (Teks/Media) yang di-reply sebagai story grup.',
    async execute(sock, m, args, { isOwner, isGroup }) {

        if (!isGroup) return m.reply('⚠️ Gunakan command ini di dalam grup, atau ketik .swgc all untuk kirim ke semua grup (Owner Only).');

        // ===== 1. Cek admin =====
        let isRealAdmin = false;
        try {
            const groupMetadata = await sock.groupMetadata(m.chat);
            const participant = groupMetadata.participants.find(p => p.id === m.sender);
            if (participant && (participant.admin === 'admin' || participant.admin === 'superadmin')) {
                isRealAdmin = true;
            }
        } catch (e) {
            console.log("Gagal ngecek admin:", e);
        }

        if (!isOwner && !isRealAdmin) return m.reply('❌ Hanya Admin/Owner grup yang bisa pakai command ini!');

        try {
            // Panggil modul di dalam fungsi biar anti error ESM!
            const { generateWAMessageContent, generateWAMessageFromContent, getContentType, downloadContentFromMessage } = await import('@whiskeysockets/baileys');
            const crypto = require('crypto');

            // ===== Deteksi Reply Anti-Rabun =====
            const rawMsg = m.original ? m.original.message : m.message;
            const type = getContentType(rawMsg);

            // Ambil pesan reply langsung dari jantung Baileys
            let quotedMsg = rawMsg[type]?.contextInfo?.quotedMessage;

            // Fallback kalau handler lu pakai format lain
            if (!quotedMsg) {
                if (m.quoted && m.quoted.message) quotedMsg = m.quoted.message;
                else if (m.quoted) quotedMsg = m.quoted;
            }

            if (!quotedMsg || Object.keys(quotedMsg).length === 0) {
                return m.reply('⚠️ Reply pesan (Teks/Foto/Video/Audio) yang mau dijadikan story grup!');
            }

            await m.react('⏳');

            const ct = getContentType(quotedMsg);
            let buffer = null;

            // ===== Download Media Anti Gagal =====
            if (ct === 'imageMessage' || ct === 'videoMessage' || ct === 'audioMessage') {
                try {
                    // Coba pakai m.download() bawaan base lu
                    buffer = await m.download();
                } catch (e) {
                    try {
                        // Kalau gagal, pakai raw Baileys downloader
                        const mediaType = ct.replace('Message', '');
                        const stream = await downloadContentFromMessage(quotedMsg[ct], mediaType);
                        let streamBuffer = Buffer.from([]);
                        for await (const chunk of stream) {
                            streamBuffer = Buffer.concat([streamBuffer, chunk]);
                        }
                        buffer = streamBuffer;
                    } catch (err) {
                        console.log("Gagal download media:", err);
                    }
                }
            }

            // ===== 2. Helper function =====
            async function sendGroupStatus(jid, contentObj) {
                const bgColor = contentObj.backgroundColor;
                delete contentObj.backgroundColor;

                const inside = await generateWAMessageContent(contentObj, {
                    upload: sock.waUploadToServer,
                    backgroundColor: bgColor
                });

                const messageSecret = crypto.randomBytes(32);

                const msg = generateWAMessageFromContent(jid, {
                    messageContextInfo: { messageSecret },
                    groupStatusMessageV2: {
                        message: {
                            ...inside,
                            messageContextInfo: { messageSecret }
                        }
                    }
                }, {});

                await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
            }

            // ===== 3. Siapkan content sesuai tipe =====
            let contentToUpload = {};

            if (ct === 'conversation' || ct === 'extendedTextMessage') {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '';
                const colors = ['#FF3B30','#34B7F1','#25D366','#FFD700','#9C27B0','#000000'];
                contentToUpload = { text, backgroundColor: colors[Math.floor(Math.random()*colors.length)] };

            } else if (ct === 'imageMessage') {
                if (!buffer) return m.reply('❌ Gagal mendownload gambar!');
                const caption = quotedMsg.imageMessage?.caption || '';
                contentToUpload = { image: buffer, caption };

            } else if (ct === 'videoMessage') {
                if (!buffer) return m.reply('❌ Gagal mendownload video!');
                const caption = quotedMsg.videoMessage?.caption || '';
                contentToUpload = { video: buffer, caption };

            } else if (ct === 'audioMessage') {
                if (!buffer) return m.reply('❌ Gagal mendownload audio!');
                contentToUpload = { audio: buffer, mimetype: 'audio/mp4', ptt: true };

            } else {
                await m.react('❌');
                return m.reply('⚠️ Tipe pesan belum didukung! (Cuma Teks, Foto, Video, Audio)');
            }

            // ===== 4. Mode broadcast all =====
            if (args[0] && args[0].toLowerCase() === 'all') {
                if (!isOwner) return m.reply('❌ Fitur kirim ke semua grup cuma buat Owner!');
                const allGroups = await sock.groupFetchAllParticipating();
                const grupList = Object.keys(allGroups);
                let suksesCount = 0;

                for (let gid of grupList) {
                    try {
                        await sendGroupStatus(gid, contentToUpload);
                        suksesCount++;
                        // Delay biar aman dari banned Meta
                        await new Promise(r=>setTimeout(r,2000));
                    } catch(e) {
                        console.log(`[SWGC ERROR] Gagal kirim ke ${gid}:`, e);
                    }
                }

                await m.react('✅');
                return m.reply(`✅ Berhasil mengirim status ke ${suksesCount} grup!`);
            }

            // ===== 5. Mode normal: grup saat ini =====
            await sendGroupStatus(m.chat, contentToUpload);
            await m.react('✅');
            await m.reply('✅ Berhasil upload story di grup ini!\n\n_© Sawit Community_');

        } catch (err) {
            console.error('[SWGC ERROR]', err);
            await m.react('❌');
            await m.reply('Gagal: '+err.message);
        }
    }
};
