const axios = require('axios');
const moment = require('moment-timezone');

module.exports = {
    name: 'rstalk',
    alias: ['rbxstalk', 'roblox', 'stalkroblox'],
    description: 'Stalking detail akun Roblox berdasarkan username',
    async execute(sock, msg, args) {
        // Username Roblox kaga pake spasi, jadi ambil args pertama aja
        const username = args[0]; 

        if (!username) {
            return msg.reply("❗ *Format Salah!*\nCara pakai: `.rstalk <username>`\nContoh: `.rstalk Builderman`");
        }

        // Kasih reaction loading biar user tau bot lagi kerja
        await msg.react('⏳');

        try {
            // 1. Cari User ID berdasarkan Username
            const searchRes = await axios.post('https://users.roblox.com/v1/usernames/users', {
                usernames: [username],
                excludeBannedUsers: false
            });

            if (!searchRes.data?.data?.length) {
                await msg.react('❌');
                return msg.reply(`❌ Username *${username}* tidak ditemukan di database Roblox!`);
            }

            const userId = searchRes.data.data[0].id;

            // 2. Tarik Data Serentak (Biar Ngebut!) 
            // Ambil Detail, Avatar, Followers, dan Friends sekaligus
            const [detailRes, thumbRes, followerRes, friendRes] = await Promise.all([
                axios.get(`https://users.roblox.com/v1/users/${userId}`),
                axios.get(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png&isCircular=false`),
                axios.get(`https://friends.roblox.com/v1/users/${userId}/followers/count`).catch(() => ({ data: { count: '-' } })),
                axios.get(`https://friends.roblox.com/v1/users/${userId}/friends/count`).catch(() => ({ data: { count: '-' } }))
            ]);

            const d = detailRes.data;
            const img = thumbRes.data?.data?.[0]?.imageUrl;
            const followers = followerRes.data?.count || '-';
            const friends = friendRes.data?.count || '-';

            // Format tanggal join biar cakep ala Indo
            const joinDate = moment(d.created).tz('Asia/Jakarta').format('DD MMMM YYYY');

            // 3. Render Tampilan UI Super Elit
            let teks = `╭━━━〔 *ROBLOX STALKER* 〕━━━┈ ⳹\n`
            teks += `┃ 👤 *Username:* ${d.name}\n`
            teks += `┃ 🏷️ *Display Name:* ${d.displayName}\n`
            teks += `┃ 🆔 *User ID:* ${d.id}\n`
            teks += `┃ 👥 *Followers:* ${followers}\n`
            teks += `┃ 🤝 *Friends:* ${friends}\n`
            teks += `┃ 🔴 *Status:* ${d.isBanned ? '⛔ BANNED' : '✅ ACTIVE'}\n`
            teks += `┃ 📅 *Join Date:* ${joinDate}\n`
            teks += `╰━━━━━━━━━━━━━━━━━━━━━━┈ ⳹\n\n`
            
            teks += `*📝 Deskripsi (Bio):*\n${d.description ? `"${d.description}"` : "_User ini tidak memiliki bio._"}\n\n`
            
            teks += `*🔗 Profile Link:*\nhttps://www.roblox.com/users/${d.id}/profile\n\n`
            teks += `_© Xploria Bot x Sawit Community_`

            // 4. Kirim Hasil
            if (img && img !== 'null') {
                await sock.sendMessage(msg.chat, { 
                    image: { url: img }, 
                    caption: teks 
                }, { quoted: msg.original });
            } else {
                await msg.reply(teks);
            }

            // Reaction Sukses
            await msg.react('✅');

        } catch (err) {
            console.error("[ROBLOX STALK ERROR]", err.message);
            await msg.react('❌');
            msg.reply("❌ Waduh, terjadi gangguan teknis saat mengambil data dari API Roblox. Coba lagi nanti ya!");
        }
    }
};
