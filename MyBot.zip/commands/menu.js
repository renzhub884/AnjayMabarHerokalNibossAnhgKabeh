const config = require('../config');
const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');
const axios = require('axios'); 

let cachedGifBuffer = null; 

module.exports = {
    name: 'menu',
    alias: ['help', 'h'],
    description: 'Menu WhatsApp Bot',
    async execute(sock, m, args) {
        const jam = moment().tz(config.timezone).format('HH');
        let ucapan = jam >= 18 || jam < 4 ? 'Selamat Malam 🌙' : jam >= 15 ? 'Selamat Sore 🌥️' : jam >= 11 ? 'Selamat Siang 🌤️' : 'Selamat Pagi ☀️';

        const tanggal = moment().tz(config.timezone).format('DD MMMM YYYY');
        const waktu = moment().tz(config.timezone).format('HH:mm:ss');
        
        // Path folder commands
        const commandsPath = __dirname; 
        
        let cmdList = {};
        let totalCommands = 0;
        let processedCmds = new Set(); 

        const items = fs.readdirSync(commandsPath);
        for (const item of items) {
            const itemPath = path.join(commandsPath, item);
            if (fs.statSync(itemPath).isDirectory()) {
                const cat = item.toLowerCase();
                const files = fs.readdirSync(itemPath).filter(f => f.endsWith('.js'));
                if (files.length > 0) {
                    if (!cmdList[cat]) cmdList[cat] = [];
                    for (const f of files) {
                        const name = f.replace('.js', '');
                        cmdList[cat].push(name);
                        processedCmds.add(name); 
                        totalCommands++;
                    }
                }
            } 
        }

        // Karena handler udah dibenerin, m.senderNumber PASTI BERISI NOMOR HP ASLI!
        const userNum = m.senderNumber; 
        const menuGif = 'https://cdn.nekohime.site/file/duNQj1c_'; 

        let menuText = `
╭───  *${config.botName.toUpperCase()}* ───
│ 👤 *User:* ${m.pushName || 'Empty'}
│ 📱 *Num:* ${userNum}
│ 📅 *Date:* ${tanggal}
│ ⌚ *Time:* ${waktu}
╰───────────────────

*${ucapan}* \nSemoga hari mu menyenangkan 🥰✌️\n\n`;

        const categoryEmoji = { owner: '👑', maker: '🛠️', general: '🤖', downloader: '📥', tools: '🧰' };
        for (const cat of Object.keys(cmdList).sort()) {
            menuText += `*╭──  〈 ${categoryEmoji[cat] || '🧩'} ${cat.toUpperCase()} 〉*\n${cmdList[cat].sort().map(v => `│ ◦ .${v}`).join('\n')}\n*╰──────────────*\n\n`;
        }

        menuText += `Join Our Community: \nDiscord : https://discord.gg/7PhnNwdnaX \nWhatsApp : https://chat.whatsapp.com/L0kQgqtQPGk8nxlu4PLj5G`;

        await m.react('📜');

        try {
            if (!cachedGifBuffer) {
                const { data } = await axios.get(menuGif, { responseType: 'arraybuffer' });
                cachedGifBuffer = Buffer.from(data); 
            }

            // 1. KIRIM VIDEO MENU NYA DULU
            const menuMsg = await sock.sendMessage(m.from, {
                video: cachedGifBuffer,
                caption: menuText,
                gifPlayback: true,
                mimetype: 'video/mp4',
                contextInfo: {
                    forwardingScore: 999, 
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363319043254555@newsletter', 
                        newsletterName: 'nyawit lu', 
                        serverMessageId: -1 
                    }
                }
            }, { quoted: m.original });
            
            // ==========================================
            // 2. FITUR KIRIM MUSIK BGM (AUDIO BIASA)
            // ==========================================
            // process.cwd() nyari folder dari root bot lu
            const audioPath = path.join(process.cwd(), 'music', 'sibah.mp3');
            
            if (fs.existsSync(audioPath)) {
                await sock.sendMessage(m.from, {
                    audio: { url: audioPath },
                    mimetype: 'audio/mpeg', // WAJIB audio/mpeg buat file .mp3
                    ptt: false // WAJIB false biar dikirim sebagai lagu biasa (Bisa di-play)
                }, { quoted: menuMsg }); // Di-reply ke pesan video menu di atasnya
            } else {
                console.log(`[WARNING] File musik tidak ditemukan di: ${audioPath}`);
            }

        } catch (error) {
            await sock.sendMessage(m.from, { text: menuText }, { quoted: m.original });
        }
    }
};
