module.exports = {
    name: 'hidetag',
    alias: ['ht', 'pengumuman', 'announce', 'totag'],
    description: 'Tag semua member grup secara diam-diam (Ghost Tag)',
    async execute(sock, m, args, { isGroup, isAdmin, isOwner }) {
        
        if (!isGroup) return m.reply('❌ Command sakti ini cuma bisa dipakai di dalam grup, wir!');

        if (!isAdmin && !isOwner) {
            return m.reply('❌ Lu siapa mbud? Fitur hidetag cuma khusus buat Admin/CEO grup! 🗿');
        }

        // Kalau kaga ada teks, bot bakal ngirim karakter transparan (\u200B)
        const textToHide = args.length > 0 ? args.join(' ') : '\u200B';

        try {
            // Tarik data seluruh member grup saat ini
            const groupMetadata = await sock.groupMetadata(m.chat);
            const participants = groupMetadata.participants.map(p => p.id);

            // Eksekusi Hidetag murni tanpa embel-embel reaction
            await sock.sendMessage(m.chat, { 
                text: textToHide, 
                mentions: participants 
            });

        } catch (err) {
            console.error('[HIDETAG ERROR]', err);
            m.reply('❌ Gagal narik data member grup nih wir, coba lagi!');
        }
    }
};
