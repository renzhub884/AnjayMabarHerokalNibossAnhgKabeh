module.exports = {
    name: 'bypass',
    alias: ['skip', 'tembus'],

    async execute(sock, msg, args) {
        const { reply } = msg;

        try {
            const link = args[0];
            if (!link) return reply("Link?");

            await reply("...");

            const api = `https://pbx1botapi.vercel.app/api/hubcloud?url=${encodeURIComponent(link)}`;
            const res = await fetch(api);
            const data = await res.json();
            
            // Bongkar semua value, cari yang link-nya panjang (biasanya link download asli)
            let allLinks = [];
            const findLinks = (obj) => {
                for (let key in obj) {
                    if (typeof obj[key] === 'string' && obj[key].startsWith('http')) allLinks.push(obj[key]);
                    else if (typeof obj[key] === 'object') findLinks(obj[key]);
                }
            };
            findLinks(data);

            // Filter link yang bukan cuma domain hubcloud doang
            const hasil = allLinks.find(l => l.includes('download') || l.length > 25) || allLinks[0];

            if (hasil) {
                let teks = `*BYPASS RESULT*\n`
                teks += `┌───────────────────\n`
                teks += `│ 🔗 *Url:* ${hasil}\n`
                teks += `└───────────────────`
                await reply(teks);
            } else {
                await reply("Gagal: Link ga valid.");
            }

        } catch (err) {
            console.log(err);
            await reply(`Error: ${err.message}`);
        }
    }
};
