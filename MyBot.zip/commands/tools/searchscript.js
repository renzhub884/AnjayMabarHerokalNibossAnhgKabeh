const axios = require('axios');
const config = require('../../config');

module.exports = {
    name: 'ssc',
    alias: ['searchscript', 'findsc', 'sc', 'ss'],
    description: 'Mencari script Roblox di ScriptBlox',
    async execute(sock, msg, args) {
        const query = args.join(' ');
        
        if (!query) {
            return msg.reply(`❌ *Format Salah!*\n\nGunakan: ${config.prefix}ssc <nama script>\nContoh: ${config.prefix}ssc blox fruits`);
        }

        await msg.react('🔍');

        try {
            const response = await axios.get(`https://scriptblox.com/api/script/search?q=${encodeURIComponent(query)}`, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    'Accept': 'application/json'
                },
                timeout: 10000
            });

            const data = response.data;
            const scripts = data.result?.scripts || [];

            if (scripts.length === 0) {
                await msg.react('❌');
                return msg.reply(`❌ Script *"${query}"* tidak ditemukan di ScriptBlox.`);
            }

            const topScripts = scripts.slice(0, 5);
            
            // Header Tampilan Baru
            let hasil = `🔍 *S C R I P T B L O X   S E A R C H*\n\n`;
            hasil += `乂 *Detail Pencarian*\n`;
            hasil += `› *Query:* ${query}\n`;
            hasil += `› *Total Ditemukan:* ${scripts.length} scripts\n\n`;
            hasil += `*• T O P  5  R E S U L T S •*\n\n`;

            // Looping Script
            topScripts.forEach((script, index) => {
                const loadstring = `loadstring(game:HttpGet("https://scriptblox.com/raw/${script.slug}"))()`;
                
                // Cek status Key System (true/false)
                const isKeySystem = script.key ? 'Ya 🔐' : 'Tidak (Keyless) 🔓';
                
                hasil += `*${index + 1}. ${script.title}*\n`;
                hasil += `› 🎮 *Game:* ${script.game?.name || 'Universal'}\n`;
                hasil += `› 🔑 *Key System:* ${isKeySystem}\n`;
                hasil += `› 👁️ *Views:* ${script.views?.toLocaleString() || '0'}\n`;
                hasil += `› 🔗 *Link:* https://scriptblox.com/script/${script.slug}\n`;
                hasil += `› 💻 *Loadstring:*\n`;
                hasil += `\`\`\`lua\n${loadstring}\n\`\`\`\n\n`;
            });

            // Footer Tampilan Baru
            hasil += `© *Created by ${config.ownerName}*`;

            await msg.react('✅');
            await msg.reply(hasil);

        } catch (error) {
            console.error('SearchScript Error:', error.message);
            await msg.react('❌');

            if (error.response?.status === 403) {
                msg.reply(`❌ *Error 403:* Akses diblokir oleh Cloudflare. Coba lagi nanti.`);
            } else {
                msg.reply(`❌ *Terjadi Kesalahan:* ${error.message}`);
            }
        }
    }
};
