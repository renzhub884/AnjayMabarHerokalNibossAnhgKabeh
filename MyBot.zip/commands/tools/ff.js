const axios = require('axios');

module.exports = {
    name: 'ff',
    alias: ['ffnews', 'beritaff'],
    description: 'Menampilkan berita terbaru Free Fire',
    async execute(sock, m, args) {
        await m.react('⏳');

        try {
            const { data } = await axios.get('https://api.nexray.web.id/berita/ffnews');
            
            const result = data.data || data.result || data;
            const news = Array.isArray(result) ? result[0] : result;

            if (!news) {
                await m.react('❌');
                return m.reply('Waduh, lagi kaga ada berita FF terbaru nih wir.');
            }

            const title = news.title || news.judul || 'Berita Free Fire';
            const desc = news.desc || news.description || news.deskripsi || news.content || 'Tidak ada penjelasan detail.';
            const image = news.image || news.img || news.gambar || news.thumb || 'https://files.catbox.moe/an42bs.jpg';

            let captionText = `🎮 *BERITA FREE FIRE TERBARU* 🎮\n\n`;
            captionText += `*📌 Topik:* ${title}\n\n`;
            captionText += `*📝 Penjelasan:*\n${desc}\n\n`;
            captionText += `_© Sawit Community_`;

            await sock.sendMessage(m.from, {
                image: { url: image },
                caption: captionText
            }, { quoted: m.original });

            await m.react('✅');

        } catch (error) {
            console.error("FF News Error:", error);
            await m.react('❌');
            await m.reply('Gagal ngambil berita FF, mungkin API lagi down atau error.');
        }
    }
};
