const config = require('../../config');

module.exports = {
    name: 'restart',
    alias: ['reset', 'reboot'],
    description: 'Me-restart proses bot',
    async execute(sock, msg, args) {
        const senderId = msg.sender.split('@')[0];
        const isOwner = config.ownerNumber.includes(senderId);
        if (!isOwner) return msg.reply(config.messages.owner);

        await msg.react('⏳');
        
        const teks = `
╔══════════════════════════════╗
║      🔄 SYSTEM RESTART       ║
╚══════════════════════════════╝

┌─ ⟨ STATUS ⟩
│ Mode   : Automatic Restart
│ User   : ${msg.pushname}
└────────────────────────

Pesan: Sedang memulai ulang bot...
        `.trim();

        await msg.reply(teks);

        setTimeout(() => {
            process.exit(0); 
        }, 1000);
    }
};
