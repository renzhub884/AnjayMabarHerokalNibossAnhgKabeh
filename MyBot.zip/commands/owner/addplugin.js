const fs = require('fs');
const path = require('path');
const config = require('../../config');

module.exports = {
    name: 'addplugin',
    alias: ['ap', 'addcode'],
    description: 'Menambah atau update file command via reply teks',
    async execute(sock, msg, args) {
        const senderId = msg.sender.split('@')[0];
        const isOwner = config.ownerNumber.includes(senderId);
        if (!isOwner) return msg.reply(config.messages.owner);

        if (!msg.quoted || !msg.quoted.text) {
            return msg.reply("❌ *WAJIB REPLY TEKS*\n\nBalas pesan yang berisi kode script lalu ketik *.addplugin namafile*");
        }

        let fileName = args[0];
        if (!fileName) return msg.reply(`📦 Contoh: *${config.prefix}addplugin fitur_baru*`);

        fileName = fileName.toLowerCase().replace('.js', '');
        const filePath = path.join(__dirname, `${fileName}.js`);

        if (msg.react) await msg.react('⏳');

        try {
            fs.writeFileSync(filePath, msg.quoted.text);
            
            let caption = `\`\`\`╔══════════════════════════════╗\`\`\`\n`
            caption += `\`\`\`║     📥 ADD PLUGIN SUCCESS     ║\`\`\`\n`
            caption += `\`\`\`╚══════════════════════════════╝\`\`\`\n\n`
            caption += `┌─ ⟨ *DETAIL* ⟩\n`
            caption += `│ 💠 *Status:* \`Created/Updated\`\n`
            caption += `│ 📄 *Name:* \`${fileName}.js\`\n`
            caption += `│ 📂 *Path:* \`./commands/${fileName}.js\`\n`
            caption += `└────────────────────────\n\n`
            caption += `_Silakan ketik *.restart* untuk memuat fitur baru._`

            await msg.reply(caption);
            if (msg.react) await msg.react('✅');
        } catch (error) {
            console.error(error);
            msg.reply(`❌ Gagal menulis file: ${error.message}`);
        }
    }
};
