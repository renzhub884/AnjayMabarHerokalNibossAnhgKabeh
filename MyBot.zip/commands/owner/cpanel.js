const axios = require('axios');

const domain = 'https://oline.jkt48-private.com';
const ptla = 'ptla_CkGBBYPjTPAV6q12qO62v5spcC1cbjiONc5KyZ5gjOU';
const ptlc = 'ptlc_gdSq2pTnpq0LXQUQmc4M4GLf98qeDkYF3hEJBG8FEMz'; 

const locationId = 1; 
const eggId = 15; 

module.exports = {
    name: 'panel',
    alias: ['1gb', '2gb', '3gb', '4gb', '5gb', '6gb', '7gb', '8gb', '9gb', '10gb', 'unli'],
    description: 'Auto Create User & Server Pterodactyl',
    async execute(sock, m, args, { prefix, command, isOwner }) {
        
        // ==========================================
        // PENGECEKAN OWNER SUPER AKURAT DARI CONFIG
        // ==========================================
        if (!isOwner) {
            return m.reply('lu siapa mbud mo create panel, ceo? 🗿');
        }

        const username = args[0];
        const targetNumRaw = args[1];

        if (!username || !targetNumRaw) {
            return m.reply(`⚠️ Format salah!\nContoh: *${prefix}${command} sawit 628123456789*`);
        }

        // Ngebersihin nomor WA pembeli biar formatnya bener jadi JID
        const targetNum = targetNumRaw.replace(/[^0-9]/g, '');
        const targetJid = targetNum + '@s.whatsapp.net';

        // Hitungan RAM, CPU, DISK
        let mem = 0, cpu = 0, disk = 0;
        
        if (command === 'unli') {
            mem = 0; cpu = 0; disk = 0; // 0 di Pterodactyl itu artinya Unlimited
        } else if (command.endsWith('gb')) {
            const val = parseInt(command.replace('gb', ''));
            mem = val * 1024; 
            cpu = val * 50; 
            disk = val * 1024;
        } else {
            return m.reply('⚠️ Command ukuran panel tidak dikenali.');
        }

        // Bikin password: username + 4 huruf/angka acak + 2 angka acak
        const password = username + Math.random().toString(36).substring(2, 6) + Math.floor(Math.random() * 99);

        await m.react('⏳');

        try {
            // 1. PROSES BIKIN USER BARU
            const userRes = await axios.post(`${domain}/api/application/users`, {
                email: `${username}@sawit.com`,
                username: username,
                first_name: username,
                last_name: 'Member',
                language: 'en',
                password: password
            }, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ptla}`
                }
            });

            const userId = userRes.data.attributes.id;

            // 2. PROSES BIKIN SERVER KE USER TERSEBUT
            const srvRes = await axios.post(`${domain}/api/application/servers`, {
                name: `${username} - ${command.toUpperCase()}`,
                user: userId,
                egg: eggId,
                docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
                startup: 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/node /home/container/{{MAIN_FILE}}',
                environment: {
                    SERVER_JARFILE: 'server.jar',
                    BUILD_NUMBER: 'latest',
                    STARTUP: 'node index.js'
                },
                limits: { memory: mem, swap: 0, disk: disk, io: 500, cpu: cpu },
                feature_limits: { databases: 1, backups: 1, allocations: 1 },
                deploy: { locations: [locationId], dedicated_ip: false, port_range: [] }
            }, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ptla}`
                }
            });

            // 3. PROSES NGIRIM PESAN LOGIN KE NOMOR PEMBELI
            let pesanTarget = `✅ *AKUN PANEL BERHASIL DIBUAT* ✅\n\n`;
            pesanTarget += `Halo ${username}, pesanan panel *${command.toUpperCase()}* kamu sudah siap!\n\n`;
            pesanTarget += `🖥️ *DETAIL LOGIN:*\n`;
            pesanTarget += `› *URL Login:* ${domain}\n`;
            pesanTarget += `› *Username:* ${username}\n`;
            pesanTarget += `› *Password:* ${password}\n\n`;
            pesanTarget += `⚠️ *PERINGATAN:*\n`;
            pesanTarget += `Harap simpan data ini baik-baik dan jangan disebarkan.\n\n`;
            pesanTarget += `_© Sawit Community_`;

            await sock.sendMessage(targetJid, { text: pesanTarget });

            // 4. PROSES NGASIH LAPORAN SUKSES KE LU (ADMIN)
            let pesanAdmin = `✅ *PANEL ${command.toUpperCase()} SUDAH JADI*\n\n`;
            pesanAdmin += `› *User:* ${username}\n`;
            pesanAdmin += `› *Target:* ${targetNum}\n`;
            pesanAdmin += `› *Password:* ${password}\n`;
            pesanAdmin += `› *Status:* Sukses dikirim ke DM pembeli! 🚀`;

            await m.react('✅');
            return m.reply(pesanAdmin);

        } catch (err) {
            console.error(err.response?.data || err.message);
            await m.react('❌');
            const errorMessage = err.response?.data?.errors?.[0]?.detail || err.message;
            return m.reply(`❌ Gagal mengeksekusi API Reviactyl/Pterodactyl:\n${errorMessage}`);
        }
    }
};
