const fs = require('fs');
const path = require('path');
const config = require('../../config');

module.exports = {
    name: 'delplugin',
    alias: ['dp', 'delcode'],
    description: 'Menghapus file command dari server',
    async execute(sock, msg, args) {
        const senderId = msg.sender.split('@')[0];
        const isOwner = config.ownerNumber.includes(senderId);
        if (!isOwner) return msg.reply(config.messages.owner);

        let fileName = args[0];
        if (!fileName) return msg.reply(`📦 Contoh: *${config.prefix}delplugin fitur_lama*`);

        fileName = fileName.toLowerCase().replace('.js', '');
        const filePath = path.join(__dirname, `${fileName}.js`);

        if (!fs.existsSync(filePath)) {
            return msg.reply(`❌ File *${fileName}.js* tidak ditemukan di folder commands.`);
        }

        if (msg.react) await msg.react('🗑️');

        try {
            fs.unlinkSync(filePath);
            
            let caption = `\`\`\`╔══════════════════════════════╗\`\`\`\n`
            caption += `\`\`\`║     🗑️ DEL PLUGIN SUCCESS     ║\`\`\`\n`
            caption += `\`\`\`╚══════════════════════════════╝\`\`\`\n\n`
            caption += `┌─ ⟨ *DETAIL* ⟩\n`
            caption += `│ 💠 *Status:* \`Permanently Deleted\`\n`
            caption += `│ 📄 *Name:* \`${fileName}.js\`\n`
            caption += `└────────────────────────\n\n`
            caption += `_File telah dihapus dari server._`

            await msg.reply(caption);
            if (msg.react) await msg.react('✅');
        } catch (error) {
            console.error(error);
            msg.reply(`❌ Gagal menghapus file: ${error.message}`);
        }
    }
};
