const config = require('../../config');

module.exports = {
    name: 'mode',
    alias: ['setmode'],
    description: 'Mengubah mode bot (Self/Public)',
    async execute(sock, msg, args) {
        if (!msg.isOwner) return msg.reply("❌ Khusus Owner, lu siape mpruy? ngatur² gua 🗿");

        if (!args[0]) return msg.reply(`Mode saat ini: *${config.public ? 'PUBLIC' : 'SELF'}*\n\nKetik:\n*.mode public* (Bisa dipakai semua orang)\n*.mode self* (Hanya owner)`);

        const input = args[0].toLowerCase();
        if (input === 'public' || input === 'p') {
            config.public = true;
            msg.reply("🔓 Bot sekarang dalam mode *PUBLIC*.");
        } else if (input === 'self' || input === 's') {
            config.public = false;
            msg.reply("🔒 Bot sekarang dalam mode *SELF*.");
        } else {
            msg.reply("❌ Pilihannya cuma 'public' atau 'self' su.");
        }
    }
};
