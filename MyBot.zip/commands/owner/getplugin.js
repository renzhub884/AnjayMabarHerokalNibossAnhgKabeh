const fs = require('fs');
const path = require('path');
const config = require('../../config');

module.exports = {
    name: 'getplugin',
    alias: ['gp', 'getcode'],
    description: 'Mengambil source code file command',
    async execute(sock, msg, args) {
        const senderId = msg.sender.split('@')[0];
        const isOwner = config.ownerNumber.includes(senderId);
        
        if (!isOwner) return msg.reply(config.messages.owner);

        let fileName = args[0];
        if (!fileName) return msg.reply(`📦 Contoh: *.getplugin menu*`);

        fileName = fileName.toLowerCase().replace('.js', '');
        const filePath = path.join(__dirname, `${fileName}.js`);

        if (!fs.existsSync(filePath)) return msg.reply(`❌ File *${fileName}.js* tidak ditemukan.`);

        if (msg.react) await msg.react('⏳');
        
        try {
            const code = fs.readFileSync(filePath, 'utf-8');
            const stats = fs.statSync(filePath);
            const sizeKB = (stats.size / 1024).toFixed(2);
            
            let teks = '```╔══════════════════════════╗```\n'
            teks += '```║    💾 PLUGIN EXPORTER    ║```\n'
            teks += '```╚══════════════════════════╝```\n\n'
            teks += `*📁 File Name:* \`${fileName}.js\`\n`
            teks += `*📊 File Size:* \`${sizeKB} KB\`\n`
            teks += `*👤 Author:* \`sibah and Alrect\`\n`
            teks += '━━━━━━━━━━━━━━━━━━━━━━\n'
            teks += '🚨 *X P L O R I A • P A T R O L*\n'
            teks += '━━━━━━━━━━━━━━━━━━━━━━'

            await sock.sendMessage(msg.from, {
                document: Buffer.from(code, 'utf-8'),
                fileName: `${fileName}.js`,
                mimetype: 'application/javascript',
                caption: teks,
                contextInfo: {
                    externalAdReply: {
                        title: "FILE COMMAND EXPORTER",
                        body: `Success Exporting ${fileName}.js`,
                        thumbnailUrl: "https://files.catbox.moe/p99piz.jpg",
                        sourceUrl: "",
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            });

            if (msg.react) await msg.react('✅');
        } catch (error) {
            console.error(error);
            msg.reply(`❌ Error: ${error.message}`);
        }
    }
};
