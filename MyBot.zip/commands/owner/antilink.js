module.exports = {
    name: 'antilink',
    alias: ['al'],
    description: 'Auto delete link WhatsApp (Grup & Saluran)',
    async execute(sock, msg, args) {
        const { from, isOwner, reply, sender } = msg;

        if (!from.endsWith('@g.us')) return reply('Fitur ini khusus di grup, wir!');

        const groupMetadata = await sock.groupMetadata(from);
        const isAdmin = groupMetadata.participants.find(p => p.id === sender)?.admin || isOwner;

        if (!isAdmin) return reply('Lu bukan admin grup/owner, gak usah sok asik setel-setel! 😡');

        if (!args[0]) return reply(`Cara pakai:\n*.antilink on* (Hapus link aktif)\n*.antilink off* (Matiin)`);

        global.db = global.db || {};
        global.db.chats = global.db.chats || {};
        global.db.chats[from] = global.db.chats[from] || { antilink: false };

        if (args[0] === 'on') {
            global.db.chats[from].antilink = true;
            reply('✅ *Antilink Aktif!* Setiap link grup/saluran yang masuk bakal otomatis dihapus.');
        } else if (args[0] === 'off') {
            global.db.chats[from].antilink = false;
            reply('📴 *Antilink Dimatikan.*');
        }
    }
};
