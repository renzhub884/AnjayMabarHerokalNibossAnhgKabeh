global.kudetSpam = global.kudetSpam || {}

module.exports = {
    name: "stopkudet",
    alias: ["stopraid"],

    async execute(sock, m, args, { isGroup, isOwner }) {

        if (!isGroup) return
        if (!isOwner) return

        if (!global.kudetSpam[m.chat]) return

        global.kudetSpam[m.chat] = false

        m.reply("stopped")
    }
}