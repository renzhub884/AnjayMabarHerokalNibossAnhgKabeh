const axios = require('axios');
const AdmZip = require('adm-zip');

// ⚠️ TARUH TOKEN API VERCEL LU DI SINI ⚠️
const VERCEL_TOKEN = 'vcp_8qEFluP5YhAuoGVhMDzb4yNIheWYXfuz5rVZ9glhha2cb5EgyH4dGI0m'; 

module.exports = {
    name: 'deploy',
    alias: ['vercel', 'hosting', 'upweb', 'upzip'],
    description: 'Deploy script (Teks/File/ZIP) dengan custom domain ke Vercel',
    async execute(sock, m, args, { isOwner }) {
        
        if (!isOwner) return m.reply('❌ Lu siapa mbud? Command ini cuma buat CEO Sawit Community!');

        try {
            const { getContentType, downloadContentFromMessage } = await import('@whiskeysockets/baileys');
            
            // ===== 1. Deteksi Reply Anti-Rabun =====
            const rawMsg = m.original ? m.original.message : m.message;
            const type = getContentType(rawMsg);
            let quotedMsg = rawMsg[type]?.contextInfo?.quotedMessage;

            if (!quotedMsg) {
                if (m.quoted && m.quoted.message) quotedMsg = m.quoted.message;
                else if (m.quoted) quotedMsg = m.quoted;
            }

            if (!quotedMsg || Object.keys(quotedMsg).length === 0) {
                return m.reply('⚠️ Reply teks (script HTML) atau file ZIP yang mau di-deploy!\n\n*Contoh:* .deploy project-sawit');
            }
         
            if (!args[0]) {
                return m.reply('⚠️ Masukin nama project/domain yang lu mau!\n\n*Contoh:* .deploy web-elit');
            }

            await m.react('⏳');

            // Format nama project biar valid buat URL Vercel (huruf kecil, angka, strip)
            const projectName = args[0].toLowerCase().replace(/[^a-z0-9-]/g, '');

            const ct = getContentType(quotedMsg);
            let filesPayload = []; // Array buat nampung semua file yang mau diupload
            let buffer = null;
            let fileName = 'index.html';

            // ===== 2. Proses Konversi & Download =====
            if (ct === 'conversation' || ct === 'extendedTextMessage') {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '';
                filesPayload.push({
                    file: 'index.html',
                    data: Buffer.from(text).toString('base64'),
                    encoding: 'base64'
                });
                
            } else {
                // Tarik file kalau yang di-reply berupa dokumen/media/ZIP
                try {
                    buffer = await m.download();
                } catch (e) {
                    try {
                        const mediaType = ct.replace('Message', '');
                        const stream = await downloadContentFromMessage(quotedMsg[ct], mediaType);
                        let streamBuffer = Buffer.from([]);
                        for await (const chunk of stream) {
                            streamBuffer = Buffer.concat([streamBuffer, chunk]);
                        }
                        buffer = streamBuffer;
                    } catch (err) {
                        return m.reply('❌ Gagal mendownload file dari WhatsApp!');
                    }
                }

                if (!buffer) return m.reply('❌ File kosong atau gagal diunduh!');

                if (ct === 'documentMessage') {
                    fileName = quotedMsg.documentMessage?.fileName || 'file.bin';
                    
                    // JIKA FILE ADALAH ZIP (BONGKAR ISINYA!)
                    if (fileName.endsWith('.zip')) {
                        m.reply(`📦 _Mengekstrak file ZIP *${fileName}*..._`);
                        try {
                            const zip = new AdmZip(buffer);
                            const zipEntries = zip.getEntries(); // Ambil semua isi zip

                            for (const entry of zipEntries) {
                                // Jangan masukin folder kosong, ambil file nya aja
                                if (!entry.isDirectory) {
                                    filesPayload.push({
                                        file: entry.entryName, // Nama file beserta path (ex: css/style.css)
                                        data: entry.getData().toString('base64'),
                                        encoding: 'base64'
                                    });
                                }
                            }
                        } catch (zipErr) {
                            console.error('[ZIP EXTRACT ERROR]', zipErr);
                            return m.reply('❌ Gagal mengekstrak ZIP! Pastikan file ZIP tidak corrupt/rusak.');
                        }
                    } 
                    // JIKA DOKUMEN BIASA (BUKAN ZIP)
                    else {
                        filesPayload.push({
                            file: fileName,
                            data: buffer.toString('base64'),
                            encoding: 'base64'
                        });
                    }
                } else if (ct === 'imageMessage' || ct === 'videoMessage' || ct === 'audioMessage') {
                    const ext = ct === 'imageMessage' ? 'png' : ct === 'videoMessage' ? 'mp4' : 'mp3';
                    fileName = `media.${ext}`;
                    filesPayload.push({
                        file: fileName,
                        data: buffer.toString('base64'),
                        encoding: 'base64'
                    });
                }
            }

            if (filesPayload.length === 0) {
                await m.react('❌');
                return m.reply('⚠️ Tidak ada file valid yang bisa di-deploy!');
            }

            m.reply(`🚀 _Mengirim ${filesPayload.length} file ke Vercel (Domain: *${projectName}.vercel.app*)..._`);

            // ===== 3. Eksekusi Tembak API Vercel =====
            const res = await axios.post('https://api.vercel.com/v13/deployments?skipAutoDetectionConfirmation=1', {
                name: projectName,
                projectSettings: {
                    framework: null 
                },
                files: filesPayload, // Kirim semua file yang udah dirakit
                target: 'production'
            }, {
                headers: {
                    'Authorization': `Bearer ${VERCEL_TOKEN}`,
                    'Content-Type': 'application/json'
                }
            });

            const deployUrl = res.data.url;
            const mainUrl = `${projectName}.vercel.app`; 

            // ===== 4. Report Sukses =====
            let teks = `╭━━━〔 *VERCEL DEPLOYMENT* 〕━━━┈ ⳹\n`;
            teks += `┃ 📦 *Project:* ${projectName}\n`;
            teks += `┃ 🗂️ *Total Files:* ${filesPayload.length} file\n`;
            teks += `┃ 🟢 *Status:* SUCCESS / Ready\n`;
            teks += `╰━━━━━━━━━━━━━━━━━━━━━━┈ ⳹\n\n`;
            teks += `🔗 *Link Utama:*\n`;
            teks += `https://${mainUrl}\n\n`;
            teks += `🔗 *Link Deployment Backup:*\n`;
            teks += `https://${deployUrl}\n\n`;
            teks += `_© Sawit Community x Vercel_`;

            await m.reply(teks);
            await m.react('✅');

        } catch (err) {
            console.error('[VERCEL ERROR]', err.response?.data || err.message);
            await m.react('❌');
            const errorMessage = err.response?.data?.error?.message || err.message;
            m.reply(`❌ Gagal deploy ke Vercel!\n\n*Detail Error:* ${errorMessage}`);
        }
    }
};
