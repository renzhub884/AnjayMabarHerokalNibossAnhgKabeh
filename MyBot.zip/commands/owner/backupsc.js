const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const config = require('../../config');

module.exports = {
    name: 'backupsc',
    alias: ['backup'],
    description: 'Backup script bot ke ZIP (Tanpa Archiver)',
    async execute(sock, msg, args) {
        const senderId = msg.sender.split('@')[0];
        const isOwner = config.ownerNumber.includes(senderId);
        if (!isOwner) return msg.reply(config.messages.owner);

        if (msg.react) await msg.react('⏳');
        await msg.reply("📦 *BACKUP PROCESS*\nMengompres file lewat sistem server...");

        const timestamp = new Date().getTime();
        const zipName = `Backup_SC_${timestamp}.zip`;

        exec(`zip -r ${zipName} . -x "node_modules/*" ".git/*" ".npm/*" "sessions/*" ".cache/*"`, async (error, stdout, stderr) => {
            if (error) {
                console.error(error);
                return msg.reply(`❌ *Gagal:* Server kamu tidak mendukung perintah zip otomatis.`);
            }

            try {
                let caption = `\`\`\`╔══════════════════════════════╗\`\`\`\n`
                caption += `\`\`\`║     📦 BACKUP SC SUCCESS      ║\`\`\`\n`
                caption += `\`\`\`╚══════════════════════════════╝\`\`\`\n\n`
                caption += `📄 *File:* \`${zipName}\`\n`
                caption += `📅 *Date:* \`${new Date().toLocaleDateString('id-ID')}\`\n\n`
                caption += `🚨 *X P L O R I A • P A T R O L*`

                await sock.sendMessage(msg.from, {
                    document: fs.readFileSync(zipName),
                    fileName: zipName,
                    mimetype: 'application/zip',
                    caption: caption
                }, { quoted: msg });

                // Hapus file setelah terkirim
                fs.unlinkSync(zipName);
                if (msg.react) await msg.react('✅');
            } catch (err) {
                msg.reply("❌ File terlalu besar atau gagal dibaca.");
            }
        });
    }
};
