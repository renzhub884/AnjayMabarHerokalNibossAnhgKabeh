module.exports = {
    ownerName: "Sibah - Alrect",
    ownerNumber: [
        "6285800159659",
        "118653286633499",
        "6282192401340",
        "173237707259925"
    ],
    botNumber: "6285647198828",
    botName: "Xploria AI",
    prefix: ".",
    public: true,
    timezone: "Asia/Jakarta",
    apiScriptBlox: "https://scriptblox.com/api/script/search",
    autoRead: true,
    anticall: false,
    messages: {
        owner: "Lu ngapa dek, ini khusus owner 😜👈",
        group: "Perintah ini hanya bisa di grup!",
        private: "Perintah ini hanya bisa di private chat!",
        wait: "⏳ Tunggu sebentar...",
        error: "❌ Terjadi error!",
        notFound: "❌ Tidak ditemukan!"
    }
};
