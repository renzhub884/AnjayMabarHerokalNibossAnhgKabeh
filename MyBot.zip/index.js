const pino = require('pino');
const fs = require('fs');
const chalk = require('chalk');
const moment = require('moment-timezone');
const config = require('./config');
const { logger } = require('./lib/logger');
const { loadCommands, handleMessage } = require('./lib/handler');

async function startBot() {
    // ========================================================
    // TRIK DYNAMIC IMPORT (BYPASS ERROR ESM REQUIRE BAILEYS V7)
    // ========================================================
    const { 
        default: makeWASocket, 
        useMultiFileAuthState, 
        DisconnectReason,
        Browsers,
        jidDecode 
    } = await import('@whiskeysockets/baileys');

    const { state, saveCreds } = await useMultiFileAuthState('./database/auth_info_baileys');
    
    logger.info(`Memulai mesin Baileys v7...`);
    
    const sock = makeWASocket({
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: state,
        browser: Browsers.ubuntu('Chrome'),
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: false
    });

    // ==========================================
    // SYSTEM DECODE JID
    // ==========================================
    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const decode = jidDecode(jid) || {};
            return decode.user && decode.server ? `${decode.user}@${decode.server}` : jid;
        }
        return jid;
    };
    // ==========================================

    if (!sock.authState.creds.registered) {
        let phoneNumber = config.botNumber?.replace(/[^0-9]/g, '');

        if (!phoneNumber || phoneNumber === "6283300157829") {
            console.log(chalk.red.bold('\n⚠️  ERROR: NOMOR BOT BELUM DISETTING!'));
            process.exit(1);
        }

        setTimeout(async () => {
            try {
                // WAJIB 8 KARAKTER PAS (X-P-L-O-R-I-A-1)
                const customCode = "SAWITERS"; 
                logger.warn(`Sedang meminta kode pairing dari server Meta...`);
                
                // Masukin customCode-nya ke parameter kedua
                const code = await sock.requestPairingCode(phoneNumber, customCode);
                const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;
                
                // TAMPILAN PAIRING CODE SUPER ELIT (WARNA CYAN MURNI ANTI SILAU)
                console.log(chalk.cyan.bold('\n   ╭────────────────────────────────────────╮'));
                console.log(chalk.cyan.bold('   │') + chalk.yellow.bold('          🔑 KODE PAIRING BOT           ') + chalk.cyan.bold('│'));
                console.log(chalk.cyan.bold('   ├────────────────────────────────────────┤'));
                console.log(chalk.cyan.bold('   │') + chalk.white('     1. Buka WA > Perangkat Tertaut     ') + chalk.cyan.bold('│'));
                console.log(chalk.cyan.bold('   │') + chalk.white('     2. Tautkan dengan nomor telepon    ') + chalk.cyan.bold('│'));
                console.log(chalk.cyan.bold('   ├────────────────────────────────────────┤'));
                // Bagian ini udah gua ganti pure Cyan kaga pake background:
                console.log(chalk.cyan.bold('   │') + chalk.cyan.bold(`               ${formattedCode}                `) + chalk.cyan.bold('│'));
                console.log(chalk.cyan.bold('   ╰────────────────────────────────────────╯\n'));

            } catch (err) {
                logger.error('Gagal mendapatkan kode pairing: ' + err.message);
            }
        }, 4000);
    }

    const commands = loadCommands();
    logger.success(`Berhasil memuat ${commands.size} perintah (Plugins)`);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            let reason = lastDisconnect?.error?.output?.statusCode;
            const shouldReconnect = reason !== DisconnectReason.loggedOut;
            
            logger.error(`Koneksi terputus! Alasan: ${reason}`);
            
            if (shouldReconnect) {
                logger.warn('Mencoba menyambung kembali dalam 5 detik...');
                setTimeout(() => startBot(), 5000);
            } else {
                logger.error('Sesi dikeluarkan (Logged Out). Hapus folder session dan scan ulang.');
                process.exit(1);
            }
        } else if (connection === 'open') {
            logger.success('Koneksi Berhasil! Sistem Online.');
            
            console.log(chalk.cyan('\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓'));
            console.log(chalk.cyan('┃') + chalk.green.bold('             🚀 BOT SUDAH ONLINE!             ') + chalk.cyan('┃'));
            console.log(chalk.cyan('┃') + chalk.yellow(`  👤 Creator : Sibah                          `) + chalk.cyan('┃'));
            console.log(chalk.cyan('┃') + chalk.yellow(`  🏢 Team    : Sawit Community / RenzHub      `) + chalk.cyan('┃'));
            console.log(chalk.cyan('┃') + chalk.yellow(`  👑 User    : ${config.ownerName || 'Admin'}                 `) + chalk.cyan('┃'));
            console.log(chalk.cyan('┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n'));
        }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        try {
            if (type !== 'notify') return;
            const m = messages[0];
            if (!m.message || m.key.fromMe) return;
            
            await handleMessage(sock, m, commands);
        } catch (error) {
            logger.error('Kesalahan Handler Pesan: ' + error.message);
        }
    });

    return sock;
}

process.on('uncaughtException', (err) => {
    if (err.message.includes('EADDRINUSE')) return;
    logger.error('Uncaught Exception: ' + err.message);
});

process.on('unhandledRejection', (err) => {
    logger.error('Unhandled Rejection: ' + err.message);
});

console.clear();
console.log(chalk.cyan.bold(`
 ███████╗██╗██████╗  █████╗ ██╗  ██╗
 ██╔════╝██║██╔══██╗██╔══██╗██║  ██║
 ███████╗██║██████╔╝███████║███████║
 ╚════██║██║██╔══██╗██╔══██║██╔══██║
 ███████║██║██████╔╝██║  ██║██║  ██║
 ╚══════╝╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
`));
console.log(chalk.yellow.bold('        ✨ SAWIT COMMUNITY SCRIPTBLOX ✨\n'));
console.log(chalk.green('        👨‍💻 Created by : Sibah'));
console.log(chalk.green('        🚀 Base by    : AlipNigga\n'));
console.log(chalk.blue('=================================================='));

startBot();
